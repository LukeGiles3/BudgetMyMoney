<template>
  <div style="padding-left: 10px">
    <h1 class="headerText">BudgetMyMoney</h1>
  </div>
</template>

<script>

</script>

<style>
.headerText {
  background-color: lightgreen;
  text-align: center;
  padding: 10px;
  color: black;
}
</style>










package com.example.budgets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
